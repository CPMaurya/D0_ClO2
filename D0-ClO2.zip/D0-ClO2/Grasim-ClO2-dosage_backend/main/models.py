from django.db import models
from django.utils import timezone
# import django
from django.conf import settings
from django.utils.timezone import activate
activate(settings.TIME_ZONE)
from django.contrib import admin
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils.translation import gettext_lazy


class CustomAccountManager(BaseUserManager):
    def create_user(self, email, password, **other_fields):
        other_fields.setdefault("is_active", True)
        if not email:
            raise ValueError(gettext_lazy("You must provide an email"))
        email = self.normalize_email(email)
        user = self.model(email = email, **other_fields)
        user.set_password(password)
        user.save()
        return user
    def create_superuser(self, email, password, **other_fields):
        other_fields.setdefault("is_superuser", True)
        other_fields.setdefault("is_staff", True)
        other_fields.setdefault("is_active", True)
        return self.create_user(email, password, **other_fields)


class NewUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField( gettext_lazy("Email Address"), unique=True, )
    first_name = models.CharField(max_length=150, blank=True)
    username = models.CharField(max_length=150, blank=True, null=True)
    start_Date = models.DateTimeField(default=timezone.now)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    objects = CustomAccountManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    def __str__(self):
        return self.email


class Dosage(models.Model):
    user = models.ForeignKey(NewUser, on_delete=models.CASCADE, null=True)
    TRP2_outlet_consistency_2hr_lag = models.FloatField(blank=True, null=True)
    D0_H2SO4_flow_2hr_lag = models.FloatField(blank=True, null=True)
    D0_inlet_Kappa_Number_2hr_lag = models.FloatField(blank=True, null=True)
    Do_pH_Filtarte_2hr_lag = models.FloatField(blank=True, null=True)
    TRP_2_Viscosity_2hr_lag = models.FloatField(blank=True, null=True)
    PO2_Press_Pulp_Consistency_2hr_lag = models.FloatField(blank=True, null=True)
    Do_Tower_Inlet_Temperature_2hr_lag = models.FloatField(blank=True, null=True)
    PO_2_Press_Pulp_Flow_2hr_lag = models.FloatField(blank=True, null=True)
    d0_outlet_brightness = models.FloatField(blank=True, null=True)
    trp2_outlet_brightness = models.FloatField(blank=True, null=True)
    ClO2_concentration = models.FloatField(blank=True, null=True)
    recommended_dosage = models.FloatField(blank=True, null=True)
    date = models.DateField(default=timezone.now)
    time = models.TimeField(default=timezone.localtime)

class DosageAdmin(admin.ModelAdmin):
    list_display = (
        'user',
        'TRP2_outlet_consistency_2hr_lag',
        'D0_H2SO4_flow_2hr_lag',
        'D0_inlet_Kappa_Number_2hr_lag',
        'Do_pH_Filtarte_2hr_lag',
        'TRP_2_Viscosity_2hr_lag',
        'PO2_Press_Pulp_Consistency_2hr_lag',
        'Do_Tower_Inlet_Temperature_2hr_lag',
        'PO_2_Press_Pulp_Flow_2hr_lag',
        'd0_outlet_brightness',
        'trp2_outlet_brightness',
        'ClO2_concentration',
        'recommended_dosage',
        'date',
        'time'
    )


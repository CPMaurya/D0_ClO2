from .models import *
from rest_framework import serializers


class DosageCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dosage
        fields = ('user', 'TRP2_outlet_consistency_2hr_lag', 'D0_H2SO4_flow_2hr_lag', 
        'D0_inlet_Kappa_Number_2hr_lag', 'Do_pH_Filtarte_2hr_lag', 'TRP_2_Viscosity_2hr_lag', 
        'PO2_Press_Pulp_Consistency_2hr_lag', 'Do_Tower_Inlet_Temperature_2hr_lag', 
        'PO_2_Press_Pulp_Flow_2hr_lag', 'd0_outlet_brightness', 'trp2_outlet_brightness',
        'ClO2_concentration', 'recommended_dosage')


class DosageSerializer(serializers.ModelSerializer):
    date = serializers.DateField(format="%d-%m-%y")
    class Meta:
        model = Dosage
        fields = "__all__"


class NewUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewUser
        fields = "__all__"
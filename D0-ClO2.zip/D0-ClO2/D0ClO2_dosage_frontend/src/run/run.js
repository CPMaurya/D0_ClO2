import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './run.css';
import grasim from './images/grasin.png'
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import axios from "axios";
import moment from 'moment';
import { BASE_API_URL, USER_API, DOSAGE_ALL_API, EXPORT_CSV_DAY_API, EXPORT_CSV_RANGE_API, AUTO_URL } from '../constants/api';


function Homepage1() {
    const [id, setData] = React.useState(JSON.parse(localStorage.getItem("user_id")));
    const [r1, setr1] = React.useState("");
    const [r2, setr2] = useState("");
    const [r3, setr3] = useState("");
    const [r4, setr4] = useState("");
    const [r5, setr5] = useState("");
    const [r6, setr6] = useState("");
    const [r7, setr7] = useState("");
    const [r8, setr8] = useState("");
    const [r9, setr9] = useState(76);
    const [target_loose_pulp_viscosity, setpulp] = useState("");
    const [Target_hypo_Input, sethypo] = useState("");
    const [run_button, setrun_button] = React.useState(false);
    const [hist, sethist] = React.useState(false);
    const [from, setfrom] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
    const [to, setto] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
    const [from1, setfrom1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
    const [to1, setto1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
    const [date, setDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
    const [time, settime] = useState(new Date().toLocaleTimeString());
    const [pr, setpr] = useState("");
    const navigate = useNavigate();
    const [sheet, setData1] = useState("");
    const [active, setActive] = useState(1)
    const [updatedTime,setUpdatedTime] = useState("")
    const [updatedDate,setUpdatedDate] = useState("")
    const [recommend,setRecommend] = useState([])
    

    const showInfo = async () => {

        if (run_button === false) {
            const call = await fetch(`${BASE_API_URL}run_inputs/`, {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    "TRP2_outlet_consistency_2hr_lag": new Number(r1),
                    "D0_H2SO4_flow_2hr_lag": new Number(r2),
                    "D0_inlet_Kappa_Number_2hr_lag": new Number(r3),
                    "Do_pH_Filtarte_2hr_lag": new Number(r4),
                    "TRP_2_Viscosity_2hr_lag": new Number(r5),
                    "PO2_Press_Pulp_Consistency_2hr_lag": new Number(r6),
                    "Do_Tower_Inlet_Temperature_2hr_lag": new Number(r7),
                    "PO_2_Press_Pulp_Flow_2hr_lag": new Number(r8),
                    "d0_outlet_brightness": new Number(r9),
                    "ClO2_concentration": new Number(Target_hypo_Input),
                    "trp2_outlet_brightness": new Number(target_loose_pulp_viscosity),

                })
            })
            const res = await call.json()
            const val = res.success
            setData1(res.success)
            // console.log("value", res.success)
            if (res.success) {
                const call = await fetch(`${BASE_API_URL}clo2_dosage/all/`, {
                    method: "POST",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                    TRP2_outlet_consistency_2hr_lag: r1,
                    D0_H2SO4_flow_2hr_lag: r2,
                    D0_inlet_Kappa_Number_2hr_lag: r3,
                    Do_pH_Filtarte_2hr_lag: r4,
                    TRP_2_Viscosity_2hr_lag: r5,
                    PO2_Press_Pulp_Consistency_2hr_lag: r6,
                    Do_Tower_Inlet_Temperature_2hr_lag: r7,
                    PO_2_Press_Pulp_Flow_2hr_lag: r8,
                    d0_outlet_brightness: r9,
                    ClO2_concentration: Target_hypo_Input,
                    trp2_outlet_brightness: target_loose_pulp_viscosity,
                    recommended_dosage: String(val),
                    date: date,
                    time: time,

                    })
                })
                const resp = await call.json()
                setrun_button(true)
                axios
                    .get(`${BASE_API_URL}${USER_API}`, {
                        params: {
                            id: id
                        }
                    })
                    .then((response) => {
                        console.log('do all =', response)
                        setpr(response.data.dosages);
                    })
                    .catch((err) => console.log(err));
            }
        }

        // else {
        //     setrun_button(false);
        //     setr1("");
        //     setr2("");
        //     setr3("");
        //     setpulp("");
        //     sethypo("");
        //     setr4("");
        //     setr5("");
        //     setr6("")
        //     setr7("")
        //     setr8("")
        //     setr9("76")
        //     setData1("")
        // }
    }

    useEffect(() => {
        if (active === 1) {
            sethist(false)
        } else {
            sethist(true)
        }

    }, [active])

    const handleChange1 = (event) => {
        setfrom(event.target.value);

    };
    const handleChange2 = (event) => {
        setto(event.target.value);
    };

    const handlehist1 = () => {
        if (hist === true) {
            sethist(false);
            console.log(id);
        }
        console.log(id);
    };

    const handlehist2 = () => {
        if (hist === false) {
            sethist(true);
            console.log(id);
        }
        console.log(pr);
    };

    const updater1 = (event) => {
        setr1(event.target.value);
    };

    const updater2 = (event) => {
        setr2(event.target.value);
    };

    const updater3 = (event) => {
        setr3(event.target.value);
    };

    const updater4 = (event) => {
        setr4(event.target.value);
    };

    const updater5 = (event) => {
        setr5(event.target.value);
    };
    const updater6 = (event) => {
        setr6(event.target.value);
    };
    const updater7 = (event) => {
        setr7(event.target.value);
    };
    const updater8 = (event) => {
        setr8(event.target.value);
    };
    const updater9 = (event) => {
        setr9(event.target.value);
    };

    const updatepulp = (event) => {
        setpulp(event.target.value);
    };

    const updatehypo = (event) => {
        sethypo(event.target.value);
    };
    const csvdownload = () => {
        window.location.replace(`${BASE_API_URL}${EXPORT_CSV_DAY_API}=${1}`);
    };
    const csvdownload2 = () => {
        // window.location.replace('https://www.ripik-line-balancer-backend.com/main/export_from_to_csv/?end_date=' + to1 + '&start_date='+ from1 +'&id=' + id );
        window.location.replace(BASE_API_URL + EXPORT_CSV_RANGE_API + to1 + '&start_date=' + from1 + '&id=' + 1);
    };


    const autoRun = async () => {
        const call = await fetch(`${BASE_API_URL}${AUTO_URL}`, {
            method: "GET",
            // headers: {
            //     'Accept': 'application/json',
            //     'Content-Type': 'application/json',
            // },
            // body: JSON.stringify({
            //     "TRP2_outlet_consistency_2hr_lag": new Number(r1),
            //     "D0_H2SO4_flow_2hr_lag": new Number(r2),
            //     "D0_inlet_Kappa_Number_2hr_lag": new Number(r3),
            //     "Do_pH_Filtarte_2hr_lag": new Number(r4),
            //     "TRP_2_Viscosity_2hr_lag": new Number(r5),
            //     "PO2_Press_Pulp_Consistency_2hr_lag": new Number(r6),
            //     "Do_Tower_Inlet_Temperature_2hr_lag": new Number(r7),
            //     "PO_2_Press_Pulp_Flow_2hr_lag": new Number(r8),
            //     "d0_outlet_brightness": new Number(r9),
            //     "ClO2_concentration": new Number(Target_hypo_Input),
            //     "trp2_outlet_brightness": new Number(target_loose_pulp_viscosity),
            // })
        })
        const res = await call.json()
        // console.log('YAYYYYYAYAYAYAY', res)
        // const temp = 
        // {
        //     "TRP2_outlet_consistency_2hr_lag": 7,
        //     "D0_H2SO4_flow_2hr_lag": 7,
        //     "D0_inlet_Kappa_Number_2hr_lag": 7,
        //     "Do_pH_Filtarte_2hr_lag": 7,
        //     "TRP_2_Viscosity_2hr_lag": 7,
        //     "PO2_Press_Pulp_Consistency_2hr_lag": 7,
        //     "Do_Tower_Inlet_Temperature_2hr_lag": 7,
        //     "PO_2_Press_Pulp_Flow_2hr_lag": 7,
        //     "d0_outlet_brightness": 76,
        //     "ClO2_concentration": 7,
        //     "trp2_outlet_brightness": 7,
        //     "recommended_dosage": 5.714285714285714
        // }
        setr1(Number(res["TRP2_outlet_consistency_2hr_lag"]))
        setr2(Number(res["D0_H2SO4_flow_2hr_lag"]))
        setr3(Number(res["D0_inlet_Kappa_Number_2hr_lag"]))
        setr4(Number(res["Do_pH_Filtarte_2hr_lag"]))
        setr5(Number(res["TRP_2_Viscosity_2hr_lag"]))
        setr6(Number(res["PO2_Press_Pulp_Consistency_2hr_lag"]))
        setr7(Number(res["Do_Tower_Inlet_Temperature_2hr_lag"]))
        setr8(Number(res["PO_2_Press_Pulp_Flow_2hr_lag"]))
        setr9(Number(res["d0_outlet_brightness"]))
        sethypo(Number(res["ClO2_concentration"]))
        setpulp(Number(res["trp2_outlet_brightness"]))
        setData1(Number(res["recommended_dosage"]).toFixed(2))
        setUpdatedTime(res["updated_at"])
        // setUpdatedDate(res["updated_at"].split(',')[0])
        setRecommend(res['error sensors'])
        // const val = res.success
        // setData1(res.success)
        // console.log("value", res.success)
        // if (res.success) {
            // const call = await fetch(`${BASE_API_URL}clo2_dosage/all/`, {
            //     method: "POST",
            //     headers: {
            //         'Accept': 'application/json',
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify({
            //     TRP2_outlet_consistency_2hr_lag: r1,
            //     D0_H2SO4_flow_2hr_lag: r2,
            //     D0_inlet_Kappa_Number_2hr_lag: r3,
            //     Do_pH_Filtarte_2hr_lag: r4,
            //     TRP_2_Viscosity_2hr_lag: r5,
            //     PO2_Press_Pulp_Consistency_2hr_lag: r6,
            //     Do_Tower_Inlet_Temperature_2hr_lag: r7,
            //     PO_2_Press_Pulp_Flow_2hr_lag: r8,
            //     d0_outlet_brightness: r9,
            //     ClO2_concentration: Target_hypo_Input,
            //     trp2_outlet_brightness: target_loose_pulp_viscosity,
            //     recommended_dosage: String(val),
            //     date: date,
            //     time: time,

            //     })
            // })
            // const resp = await call.json()
            // setrun_button(true)
        axios
            .get(`${BASE_API_URL}${USER_API}`, {
                params: {
                    id: id
                }
            })
            .then((response) => {
                // console.log('do all =', response)
                setpr(response.data.dosages);
            })
            .catch((err) => console.log(err));
        // }
    }


    useEffect(()=>{
        // console.log('inside useeffect')
        const intId = setInterval(()=>{
            // console.log('inside interval')
            autoRun()
        },10000)
    },[])

    
    // INITIALLY LOAD
    // API CALL AFTER EVERY 10 SECONDS
    // DATA VARY
    // + Result

    useEffect(() => {
        const [year1, month1, day1] = to.split('-')
        setto1(day1 + "-" + month1 + "-" + year1);
        const [year, month, day] = from.split('-')
        setfrom1(day + "-" + month + "-" + year);
        setData(JSON.parse(localStorage.getItem("user_id")));
        setDate(moment(new Date()).format("YYYY-MM-DD"));
        settime(new Date().toLocaleTimeString());
        axios
            .get(`${BASE_API_URL}${USER_API}`, {
                params: {
                    id: id
                }
            })
            .then((response) => {
                // console.log('do all =', response)
                setpr(response.data.dosages);
            })
            .catch((err) => console.log(err));
        // console.log(pr);
    }, []);


    return (
        <>
            <div className='row border border-red-500 r_back_img'>
                <div className='flex justify-between mb-3 items-center'>
                    <div className='flex items-center gap-4'>
                        <img src={grasim} className='pl-2 pt-2 h-20 w-32'></img>
                        <div className='text-2xl text-blue-500'>D0 ClO2 Dosage Recommender for Harihar Plant</div>
                    </div>

                    <div onClick={() => navigate("/")} className='cursor-pointer h-10 px-6 text-white pt-2 hover:bg-blue-600  rounded-md bg-blue-400 '>Logout</div>
                </div>

                <div className="flex justify-center mb-2">
          <div className="w-96 border rounded-full bg-blue-500 grid grid-cols-2 border-blue-500 shadow-xl">
            <div
              onClick={() => setActive(1)}
              className={
                active === 1
                  ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white shadow-xl text-white border border-2 rounded-l-full py-2"
                  : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-l-full py-2 text-black hover:bg-blue-300"
              }
            >
              Run
            </div>
            <div
              onClick={() => setActive(2)}
              className={
                active === 2
                  ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white border border-2 shadow-xl text-white rounded-r-full py-2"
                  : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-r-full py-2 hover:bg-blue-300"
              }
            >
              History
            </div>
          </div>
        </div>
                {hist === false &&
                    <div className='row r_run_box'>
                        <div className='col-7'>
                            <div className='flex justify-between items-center px-2'>
                                <div className='text-blue-500 text-2xl pl-3 pt-2 pb-2'>Input Data </div>
                                <div className='flex mb-3 mt-3 items-center justify-center'>
                        <div className='text-blue-500 text-sm mr-2'>Updated at : </div>
                        <div className='text-xs bg-blue-600 text-white p-2 rounded-xl '> {updatedTime} </div>
                        {/* <div className='text-blue-500 text-sm'>Updated on : {updatedDate} </div> */}
                    </div>
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10 col-md-10 '>
                                TRP2 Outlet Consistency 2hr lag(%):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r1}
                                    onChange={updater1}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                D0 H2SO4 Flow 2hr lag(m3/hr):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r2}
                                    onChange={updater2}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                D0 Inlet Kappa Number 2hr lag:
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r3}
                                    onChange={updater3}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                D0 pH Filtarte 2hr lag:
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r4}
                                    onChange={updater4}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                TRP 2 Viscosity 2hr lag(ml/g):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r5}
                                    onChange={updater5}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                PO2 Press Pulp Consistency 2hr lag(%):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r6}
                                    onChange={updater6}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                D0 Tower Inlet Temperature 2hr lag('C):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r7}
                                    onChange={updater7}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                PO2 Press Pulp Flow 2hr lag(m3/hr):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r8}
                                    onChange={updater8}
                                />
                            </div>
                        
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                ClO2 Concentration(m3/hr):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                TRP2 Outlet Brightness(%ISO):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div>
                            <div className='mx-1 pl-3 text-sm mb-1 flex justify-between items-center mx-1 my-1 border-b-2 p-0.5'>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 col-md-10'>
                                Target D0 Outlet Brightness(%ISO):
                                </div>
                                <input
                                    className='col-4 col-md-2 r_eop_box pl-1'
                                    type="number"
                                    value={r9}
                                    onChange={updater9}
                                />
                            </div>
                            
                            {/* <div clasmName='mx-1 pl-3 text-xs mb-2'>
                                <div className='col-7 r_eop_text'>
                                ClO2_concentrati                   </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div> */}
                            {/* <div className='row'>
                                <div className='col-7 r_eop_text'>
                                trp2_outlet_brightness:
                                </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div> */}
                            {/* <div className='row r_run_button'>

                                {run_button === false &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RUN</div></div>
                                }
                                {run_button === true &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RESET</div></div>
                                }
                            </div> */}

                        </div>
                        <div className='col-1 vl'></div>
                        <div className='col-4'>
                            <div className='text-blue-500 text-2xl pl-3 ml-10 pt-3 pb-3'>Results</div>
                            {sheet &&
                                <>
                                    <div className='row r_reading_display'>
                                        <div className='r_reading_display_text'>
                                            <div>
                                                {sheet}
                                                {/* 76 */}
                                            </div>
                                        </div>
                                    </div>
                                    <div className='row r_loose_vis'>
                                        Recommended Dosage
                                    </div>

                                    {/*<div style={{ marginTop: '-7px' }} className='row r_download_button'>
                                        <div className='r_run_button_text' onClick={() => csvdownload()}><div>DOWNLOAD</div></div>
                            </div>*/}
                                </>
                            }
                            {
                                recommend.length !== 0 ? <div className='text-red-500 test-center'>Bad request due to: {recommend.map((item)=>(String(item)+', '))} sensors </div> : null
                            }
                        </div>
                    </div>
                }
                {hist === true &&
                    <div className='row r_run_box1 '>
                        <div className='row '>
                            <div className='col-3 r_run_t1'>
                                History
                            </div>
                            <div className='col-3 r_date_box'>
                                <Stack>
                                    <TextField
                                        label="FROM"
                                        type="date"
                                        value={from}
                                        onChange={handleChange1}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}

                                    />
                                </Stack>
                            </div>
                            <div className='col-3 r_date_box'>
                                <Stack>
                                    <TextField
                                        label="TO"
                                        type="date"
                                        value={to}
                                        onChange={handleChange2}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </Stack>
                            </div>
                            <div className='col-3 r_download_button2'>
                                <div className='r_run_button_text1' onClick={() => csvdownload2()}><div>Download</div></div>
                            </div>
                        </div>
                        <div style={{ marginTop: '-10px' }} className='row '>
                            <div className='h-80 overflow-y-scroll '>
                                <table>
                                    <tr>
                                        <th className='sticky top-0 text-center'>Date</th>
                                        <th className='sticky top-0 text-center'>Time</th>
                                        <th className='sticky top-0 text-center'>TRP2 Outlet Consistency 2hr lag(%)</th>
                                        <th className='sticky top-0 text-center'>D0 H2SO4 Flow 2hr lag(m3/hr)</th>
                                        <th className='sticky top-0 text-center'>D0 inlet Kappa Number 2hr lag</th>
                                        <th className='sticky top-0 text-center'>D0 pH Filtarte 2hr lag</th>
                                        <th className='sticky top-0 text-center'>TRP 2 Viscosity 2hr lag(ml/g)</th>
                                        <th className='sticky top-0 text-center'>PO2 Press Pulp Consistency 2hr lag(%)</th>
                                        <th className='sticky top-0 text-center'>D0 Tower Inlet Temperature 2hr lag(C)</th>
                                        <th className='sticky top-0 text-center'>PO 2 Press Pulp Flow 2hr lag(m3/hr)</th>
                                        <th className='sticky top-0 text-center'>TRP2 outlet brightness(%ISO)</th>
                                        <th className='sticky top-0 text-center'>ClO2 concentration</th>
                                        <th className='sticky top-0 text-center'>Recommended Dosage(m3/hr)</th>
                                        <th className='sticky top-0 text-center'>Target d0 Outlet Brightness(%ISO)</th>
                                    </tr>
                                    {[...pr].reverse().map((val1, key) => {
                                        // console.log('returned history',val1)
                                        return (
                                            <tr key={key}>
                                                <th className='color_back text-center'>{val1.date}</th>
                                                <th className='color_back text-center'>{val1.time.split('.')[0]}</th>
                                                <th className='color_back text-center'>{val1.TRP2_outlet_consistency_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.D0_H2SO4_flow_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.D0_inlet_Kappa_Number_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.Do_pH_Filtarte_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.TRP_2_Viscosity_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.PO2_Press_Pulp_Consistency_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.Do_Tower_Inlet_Temperature_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.PO_2_Press_Pulp_Flow_2hr_lag?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.trp2_outlet_brightness?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.ClO2_concentration?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.recommended_dosage?.toFixed(2)}</th>
                                                <th className='color_back text-center'>{val1.d0_outlet_brightness?.toFixed(2)}</th>
                                            </tr>
                                        )
                                    })}
                                </table>
                            </div>

                        </div>

                    </div>
                }
                <div className='row flex justify-center items-center'>
                    <div className='r_ripik'>
                        Powered by Ripik.ai
                    </div>
                </div>
            </div>
        </>
    )
}

export default Homepage1;
import { createContext } from "react"
const ValueContext = createContext()
export default ValueContext
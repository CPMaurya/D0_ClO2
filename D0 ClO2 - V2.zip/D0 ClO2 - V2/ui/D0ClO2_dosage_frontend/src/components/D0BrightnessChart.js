import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Filler,
    Legend,
  } from "chart.js";
  import { Line, getElementAtEvent, printElementAtEvent } from "react-chartjs-2";
  import { useRef, useContext } from "react";
  import axios from "axios";
  import { useState, useEffect } from "react";
  ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Filler,
    Legend
  );
  
  
  export const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
    },
  };
  const D0BrightnessChart = (props) => {
    // data = api get every 30 seconds
    // data = [value, time]
    // dataset.push(data)
    // const [plotData, setPlotData] = useState()
    // const [labels, setLabels] = useState()
    // const [update, setUpdate] = useState(false)
    const chartRef = useRef();
    const customStyles = {
      content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        width: "65%",
        boxShadow: "2px 2px	#fffafa",
        // marginTop : "10%" ,
        transform: "translate(-50%, -50%)",
        borderRadius: "20px",
      },
    };
  
    const labelData = ["original", "recommended"]
    const colors = ['red', "blue"]
    const finalData = []
    finalData.push(props.data.orig_d0_brig)
    finalData.push(props.data.recc_d0_brig)
  
    const datasets = [];
    for (let i = 0; i < finalData.length; i++) {
      datasets.push({
        label: labelData[i],
        // fill: true,
        // data: dataSet,
        data: finalData[i],
        borderColor: colors[i],
        backgroundColor: colors[i],
        pointHoverBackgroundColor: "#fff",
        pointRadius: 4,
        pointHoverRadius: 4,
      });
      console.log("datasets", datasets);
    }
  
    const data = {
      labels: props.data.timestamps,
      datasets: datasets,
    };
    //   console.log('FINAL DATA',data)
    return (
      <>
        <div
        style={{ height: "60%" }}
        >
          <Line
            className=""
            // onClick={onClick}
            options={options}
            ref={chartRef}
            data={data}
            style={{ height: "100%" }}
            className=""
          />
        </div>
      </>
    );
  };
  
  export default D0BrightnessChart;
  
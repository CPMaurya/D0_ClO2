import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import './App.css';
import ChartTab from "./chartTab";
import Login from './login/login';
import Run from './run/run';
import ValueContext from "./components/ValueContext";
import { useState } from "react";



function App() {

  const [chartData, setChartData ] = useState({});
  const [timeRange, setTimeRange] = useState({ from: null, to: null });
  const [timeToShow, setTimeToShow] = useState({ from: null, to: null });
  
  return (
    <>
    <ValueContext.Provider
    value={{chartData, setChartData, timeRange, setTimeRange, timeToShow, setTimeToShow}}
    >
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="run" element={<Run />} />
          <Route path="visual" element={<ChartTab />} />
        </Routes>
      </BrowserRouter>
      </ValueContext.Provider>
      {/* <Run></Run> */}
    </>
  );
}

export default App;
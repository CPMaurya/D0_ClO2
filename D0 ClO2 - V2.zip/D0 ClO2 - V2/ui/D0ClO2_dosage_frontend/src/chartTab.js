import { Input } from "@material-tailwind/react";
import React, { useEffect, useState, useContext } from "react";
// import HistoryBinGraph from "../../components/HistoryBinGraph";
// import HistoryMoistureGraph from "../../components/HistoryMoistureGraph";
// import HistoryColorGraph from "../../components/HistoryColorGraph";
import axios from "axios";
import { BASE_API_URL } from "./constants/api";
import Clo2Chart from "./components/Clo2Chart";
import D0BrightnessChart from "./components/D0BrightnessChart";
import PulpBrightnessChart from "./components/PulpBrightnessChart";
import ValueContext from "./components/ValueContext";
// import ValueContext from "../../components/ValueContext";


const ChartTab = ({props}) => {
  const {chartData, setChartData, timeRange, setTimeRange, timeToShow, setTimeToShow} = useContext(ValueContext)
  
//   const {baseUrl} = useContext(ValueContext)
  
  const timeChange = (e, par) => {
    
    if(par==1){
      setTimeToShow({ to: timeToShow.to , from : e.target.value})
      console.log("FROM TIME PERIOD",e.target, e.target.value)
      // setTimeRange(prev => console.log("NEW TIMERANGE",{...prev, to:"12020"}))
      // setTimeToShow(prev => ({
      //   ...prev, from : e.target.value
      // }))
      const [date_, time] =e.target.value.split('T')
      console.log("FROMTIME",[date_, time])
      const [year, month, date] =date_.split('-')
      const [hour, minute] =time.split(':')
      // timeRange.from = new Date(int(year), int(month), int(date), int(hour), int(minute), 0)
      let val = year.toString() + "-" + month.toString() + "-" + date.toString() + " " + hour.toString() + ":" + minute.toString() + ":" + "00"
      setTimeRange( prev => ({
        ...prev,  from : val
      }))
    }
    if(par==2){
      
      setTimeToShow({ from: timeToShow.from , to : e.target.value})
      // setTimeRange(prev => console.log("NEW TIMERANGE",{...prev, from:"12020"}))
      console.log("TO TIME PERIOD", e.target, e.target.value)
      const [date_, time] =e.target.value.split('T')
      console.log("TOTIME",[date_, time])
      const [year, month, date] =date_.split('-')
      const [hour, minute] =time.split(':')
      // timeRange.from = new Date(int(year), int(month), int(date), int(hour), int(minute), 0)
      let val = year.toString() + "-" + month.toString() + "-" + date.toString() + " " + hour.toString() + ":" + minute.toString() + ":" + "00"
      setTimeRange( prev => ({
        ...prev,  to : val
      }) )
    }
  };
  
  useEffect(() => {
    if(timeRange.to !== null && timeRange.from !== null){
      console.log("INSIDE TIME RANGE", timeRange);
      
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");

      const requestData = {
        "start_date": timeRange.from,
        "end_date": timeRange.to,
      }
      apiCall(requestData, myHeaders)
    }
    
  }, [timeRange]);

  const apiCall = async (requestData, myHeaders) => {
    console.log('INSIDE API CALL', timeRange.to, timeRange.from, BASE_API_URL + "chart_data/"+ "?start_time=" + timeRange.from + "&end_time=" + timeRange.to)
    const response = await axios
      .get(BASE_API_URL + "chart_data/"+ "?start_time=" + timeRange.from + "&end_time=" + timeRange.to)
      // .then((response) => {
      //   console.log(response.data);
      //   setChartData(response.data.data);
      // })
      // .catch((error) => {
      //   console.log(error);
      // });
      console.log("GET DATA",response.data);
      setChartData(response.data);
    }



  return <div className="bg-white rounded-xl shadow-xl p-2">
      <div className="flex flex-col bg-white">
        <div className="flex justify-evenly font-bold">
          <div className="text-black flex gap-4 text-lg items-center">
            <div>From</div>
            <div className="h-24 flex items-center">
              <Input
                onChange={(e) => timeChange(e, 1)}
                name="from"
                value={timeToShow.from}
                className="h-12 bg-blue-200 rounded-xl text-lg"
                placeholder="Select Date and Time"
                format="MMM d, yyyy h:mm:ss a"
                size="lg"
                type="datetime-local"
              />
            </div>
          </div>
          <div className="text-black flex gap-4 text-lg items-center">
            <div>To</div>
            <div className="h-24 flex items-center ">
              <Input
                onChange={(e) => timeChange(e, 2)}
                name="to"
                value={timeToShow.to}
                className="h-12 bg-blue-200 rounded-xl text-lg"
                placeholder="Select Date and Time"
                format="MMM d, yyyy h:mm:ss a"
                size="lg"
                type="datetime-local"
              />
            </div>
          </div>
        </div>
        <div className="bg-white p-2 ">
          <div className="text-black font-bold text-xl p-2 shadow-xl flex justify-center items-center w-full rounded-lg bg-blue-400 shadow-lg text-base mb-4 ">
            ANALYSIS
          </div>
          <div>
            <div className='grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-3 gap-2'>
              <div className="flex flex-col flex-[1]">
                <div className="my-1 flex justify-center items-center w-full h-8 rounded-lg  bg-blue-400 shadow-xl text-base mb-2">
                  <div className=" flex justify-center font-bold text-black items-center flex-[1]">
                    CLO2 FLOW 
                  </div>
                </div>

                <div className="shadow-xl rounded-lg w-full">
                  {/* <div
                  className="w-full border rounded-lg bg-white p-2"
                  id="graphId"
                  ref={graphRef}
                  // style={{height:"50%"}}
                > */}
                  <div
                    className="w-full border rounded-lg flex items-center justify-center p-2 bg-white "
                    style={{ height: "45vh" }}
                  >
                        {chartData !== {} && Object.keys(chartData).length !== 0 ? <Clo2Chart data = {chartData} /> : null}
                  </div>
                </div>
              </div>
              <div className="flex flex-col flex-[1] ">
                <div className="my-1 flex justify-center items-center w-full h-8 rounded-lg  bg-blue-400 shadow-lg text-base mb-2">
                  <div className="flex justify-center font-bold text-black items-center flex-[1]">
                    D0 BRIGHTNESS
                  </div>
                </div>

                <div className=" shadow-xl rounded-lg w-full">
                  <div
                    className="w-full border rounded-lg bg-white p-2 flex items-center justify-center"
                    style={{ height: "45vh" }}
                  >
                      {Object.keys(chartData).length !== 0 ? <D0BrightnessChart data = {chartData}/>:null}
                  </div>
                </div>
              </div>
              <div className="flex flex-col flex-[1] ">
                <div className="my-1 flex justify-center items-center w-full h-8 rounded-lg  bg-blue-400 shadow-lg text-base mb-2">
                  <div className="flex justify-center font-bold text-black items-center flex-[1]">
                    LOOSE PULP BRIGHTNESS 
                  </div>
                </div>

                <div className=" shadow-xl rounded-lg w-full">
                  <div
                    className="w-full border rounded-lg bg-white p-2 flex items-center justify-center"
                    style={{ height: "45vh" }}
                  >
                      {Object.keys(chartData).length !== 0 ? <PulpBrightnessChart data = {chartData}/>:null} 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
};

export default ChartTab;

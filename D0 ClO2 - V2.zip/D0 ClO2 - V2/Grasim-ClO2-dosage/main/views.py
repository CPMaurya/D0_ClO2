from django.http import JsonResponse, HttpResponse
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.permissions import *
from rest_framework.response import Response
from .serializers import *
from .models import *
from braces.views import CsrfExemptMixin
import csv
from django.contrib.auth import authenticate
from django.core.mail import send_mail
from django.conf import settings
from django.db import transaction
from datetime import date, timedelta, datetime
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import pandas as pd
import numpy as np
import pickle
import os
from main.utils import get_data_from_pi, predictions, save_data_into_db
import copy


class DosageDetailView(CsrfExemptMixin, generics.RetrieveUpdateDestroyAPIView):
    permission_classes = []
    serializer_class = DosageSerializer
    queryset = Dosage.objects.all()


class DosageListView(CsrfExemptMixin, generics.ListCreateAPIView):
    permission_classes = []
    serializer_class = DosageCreateSerializer
    queryset = Dosage.objects.all()

class Brightness(APIView):
    def post(self, request):
        TRP2_outlet_consistency_2hr_lag = request.data.get('TRP2_outlet_consistency_2hr_lag')
        D0_H2SO4_flow_2hr_lag = request.data.get('D0_H2SO4_flow_2hr_lag')
        D0_inlet_Kappa_Number_2hr_lag = request.data.get('D0_inlet_Kappa_Number_2hr_lag')
        Do_pH_Filtarte_2hr_lag = request.data.get('Do_pH_Filtarte_2hr_lag')
        TRP_2_Viscosity_2hr_lag = request.data.get('TRP_2_Viscosity_2hr_lag')
        PO2_Press_Pulp_Consistency_2hr_lag = request.data.get('PO2_Press_Pulp_Consistency_2hr_lag')
        Do_Tower_Inlet_Temperature_2hr_lag = request.data.get('Do_Tower_Inlet_Temperature_2hr_lag')
        PO_2_Press_Pulp_Flow_2hr_lag = request.data.get('PO_2_Press_Pulp_Flow_2hr_lag')
        d0_outlet_brightness = request.data.get('d0_outlet_brightness')
        ClO2_concentration = request.data.get('ClO2_concentration')
        trp2_outlet_brightness = request.data.get('trp2_outlet_brightness')

        Delta_Brightness = d0_outlet_brightness - trp2_outlet_brightness

        min_bound = 40
        max_bound = 103.4
        ClO2_dosage = np.arange(min_bound, max_bound, 0.1)
        data = {}
        data['TRP2 outlet consistency_2hr_lag'] = TRP2_outlet_consistency_2hr_lag
        data['D0 - H2SO4 flow_2hr_lag'] = D0_H2SO4_flow_2hr_lag
        data['D0 inlet Kappa Number_2hr_lag'] = D0_inlet_Kappa_Number_2hr_lag
        data['Do pH Filtarte_2hr_lag'] = Do_pH_Filtarte_2hr_lag
        data['TRP 2 Viscosity_2hr_lag'] = TRP_2_Viscosity_2hr_lag
        data['PO2 Press Pulp Consistency_2hr_lag'] = PO2_Press_Pulp_Consistency_2hr_lag
        data['Do Tower Inlet Temperature_2hr_lag'] = Do_Tower_Inlet_Temperature_2hr_lag
        data['PO-2 Press Pulp Flow_2hr_lag'] = PO_2_Press_Pulp_Flow_2hr_lag

        df = pd.DataFrame(data, index=np.arange(len(ClO2_dosage)))
        df['D0_ClO2_Dosage_derived_2hr_lag'] = ClO2_dosage


        file_path = os.path.join(settings.BASE_DIR, 'Model.sav')
        model = pickle.load(open(file_path, 'rb'))
        df_value = df.values[:,:]
        predictions = model.predict(df_value)
        df['Delta_Target'] = abs(predictions - Delta_Brightness)
        del_index = list(df.index[df['Delta_Target'] == min(df['Delta_Target'])])[0]
        ClO2_flow = df['D0_ClO2_Dosage_derived_2hr_lag'].values[del_index]/ClO2_concentration
        return JsonResponse({"success": round(ClO2_flow, 2)}, status=200)

class ExportView(APIView):
    def get(self, request):
        today_date = date.today()
        print(today_date)
        user_id = request.query_params['id']
        dosage = Dosage.objects.filter(user = user_id, date = today_date)
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        # writer.writerow(['User'])
        # dosage_fields = dosage.values_list('user')
        # for dosage in dosage_fields:
        #     print(dosage)
        #     writer.writerow(dosage)
        writer.writerow([
            'date',
            'time',
            'TRP2_outlet_consistency_2hr_lag',
            'D0_H2SO4_flow_2hr_lag',
            'D0_inlet_Kappa_Number_2hr_lag',
            'Do_pH_Filtarte_2hr_lag',
            'TRP_2_Viscosity_2hr_lag',
            'PO2_Press_Pulp_Consistency_2hr_lag',
            'Do_Tower_Inlet_Temperature_2hr_lag',
            'PO_2_Press_Pulp_Flow_2hr_lag',
            'd0_outlet_brightness',
            'trp2_outlet_brightness',
            'D0_pulp_pH',
            'ClO2_concentration',
            'recommended_dosage'
        ])
        dosage_fields = dosage.values_list(
            'date',
            'time',
            'TRP2_outlet_consistency_2hr_lag',
            'D0_H2SO4_flow_2hr_lag',
            'D0_inlet_Kappa_Number_2hr_lag',
            'Do_pH_Filtarte_2hr_lag',
            'TRP_2_Viscosity_2hr_lag',
            'PO2_Press_Pulp_Consistency_2hr_lag',
            'Do_Tower_Inlet_Temperature_2hr_lag',
            'PO_2_Press_Pulp_Flow_2hr_lag',
            'd0_outlet_brightness',
            'trp2_outlet_brightness',
            'D0_pulp_pH',
            'ClO2_concentration',
            'recommended_dosage'
        )
        for dosage in dosage_fields:
            writer.writerow(dosage)
        return response


class LoginView(APIView):
    def get(self, request):
        email = request.query_params['email']
        print(email)
        otp = int(request.query_params['otp'])
        print(otp)
        user = authenticate(email=email, password=otp)
        if user is not None:
            user_object = NewUser.objects.get(email=email)
            print(user_object)
            user_id = user_object.id
            user_email = user_object.email
            data = {
                'id': user_id,
                'email': user_email,
            }
            return JsonResponse({"message": "verified", "user": data}, status=200)
        else:
            return JsonResponse({"message": "incorrect otp"}, status=200)

    def post(self, request):
        email = request.data['email']
        # def sendotpfinal(email):
        #     otp = int((random.uniform(0, 1))*100000)
        #     # print(otp)
        #     if otp <= 100000 and otp >10000:
        #         otp = f"{otp}"
        #     elif otp <= 10000 and otp >1000:
        #         otp = f"0{otp}"
        #     elif otp <= 1000 and otp >100:
        #         otp = f"00{otp}"
        #     elif otp <= 100 and otp >10:
        #         otp = f"000{otp}"
        #     elif otp <= 10 and otp >1:
        #         otp = f"0000{otp}"
        #     otp = str(otp)
        #     # print(otp)
        #     sendotp(email,otp)
        #     changepassword(email, otp)
        #     return "OTP Sent"
        # foo = sendotpfinal(email)
        try:
            user = NewUser.objects.get(email=email)
            data = {
                "id": user.id,
                "email": user.email,
            }
            return JsonResponse(data, status=200)
        except Exception as e:
            user_object = NewUser(email=email)
            user_object.save()
            print(user_object)
            user_email = user_object.email
            data = {
                "id": user_object.id,
                "email": user_email,
            }
            return JsonResponse(data, status=200)


def sendotp(email, otp):
    message = Mail(
        from_email="noreply@ripik.in",
        to_emails=email,
        subject='OTP for logging In',
        html_content=f'Your OTP for logging in is {otp}. Thank you for using our services.',
    )
    sendgrid_client = SendGridAPIClient(api_key=settings.EMAIL_HOST_PASSWORD)
    response = sendgrid_client.send(message=message)
    print(response.status_code)
    # subject = 'OTP for logging In'
    # message = f'Your OTP for logging in is {otp}. Thank you for using our services.'
    # email_from = 'noreply@ripik.in'
    # recipient_list = [email]
    # # print("email sent")
    # send_mail( subject, message, email_from, recipient_list, fail_silently=False, )


def changepassword(email, otp):
    user = NewUser.objects.all().filter(email=email).first()
    if user:
        user.set_password(otp)
        user.save()
        # print(otp)
    else:
        user = NewUser.objects.create_user(email=email, password=otp)
        print(otp)
        user.save()
    # print("passwordchanged")
    # print(user)


class UserDosageView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        dosages = Dosage.objects.all()
        serializer = DosageSerializer(dosages, many=True)
        return JsonResponse({"dosages": serializer.data}, status=200)


class MonthExportView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        today_date = date.today()
        days = today_date.day
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'date',
            'time',
            'TRP2_outlet_consistency_2hr_lag',
            'D0_H2SO4_flow_2hr_lag',
            'D0_inlet_Kappa_Number_2hr_lag',
            'Do_pH_Filtarte_2hr_lag',
            'TRP_2_Viscosity_2hr_lag',
            'PO2_Press_Pulp_Consistency_2hr_lag',
            'Do_Tower_Inlet_Temperature_2hr_lag',
            'PO_2_Press_Pulp_Flow_2hr_lag',
            'd0_outlet_brightness',
            'trp2_outlet_brightness',
            'D0_pulp_pH',
            'ClO2_concentration',
            'recommended_dosage'
        ])
        for day in range(days):

            dosage = Dosage.objects.filter(user=user_id, date=today_date)
            today_date = today_date - timedelta(days=1)
            dosage_fields = dosage.values_list(
                'date',
                'time',
                'TRP2_outlet_consistency_2hr_lag',
                'D0_H2SO4_flow_2hr_lag',
                'D0_inlet_Kappa_Number_2hr_lag',
                'Do_pH_Filtarte_2hr_lag',
                'TRP_2_Viscosity_2hr_lag',
                'PO2_Press_Pulp_Consistency_2hr_lag',
                'Do_Tower_Inlet_Temperature_2hr_lag',
                'PO_2_Press_Pulp_Flow_2hr_lag',
                'd0_outlet_brightness',
                'trp2_outlet_brightness',
                'D0_pulp_pH',
                'ClO2_concentration',
                'recommended_dosage'
            )
            for dosage in dosage_fields:
                writer.writerow(dosage)
        return response


class BetweenDateView(APIView):
    def get(self, request):
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'date',
            'time',
            'TRP2_outlet_consistency_2hr_lag',
            'D0_H2SO4_flow_2hr_lag',
            'D0_inlet_Kappa_Number_2hr_lag',
            'Do_pH_Filtarte_2hr_lag',
            'TRP_2_Viscosity_2hr_lag',
            'PO2_Press_Pulp_Consistency_2hr_lag',
            'Do_Tower_Inlet_Temperature_2hr_lag',
            'PO_2_Press_Pulp_Flow_2hr_lag',
            'd0_outlet_brightness',
            'trp2_outlet_brightness',
            'D0_pulp_pH',
            'ClO2_concentration',
            'recommended_dosage'
        ])
        start_date = request.query_params['start_date']
        end_date = request.query_params['end_date']
        user_id = request.query_params['id']
        end_date = date(int(end_date[6:]), int(end_date[3:5]), int(end_date[0:2]))
        start_date = date(int(start_date[6:]), int(start_date[3:5]), int(start_date[0:2]))
        days = (end_date - start_date).days + 1
        initial_date = start_date

        def foo(input_date):
            input_date = str(input_date)
            print(input_date)
            dosage = Dosage.objects.all()
            dosage_fields = dosage.values_list(
                'date',
                'time',
                'TRP2_outlet_consistency_2hr_lag',
                'D0_H2SO4_flow_2hr_lag',
                'D0_inlet_Kappa_Number_2hr_lag',
                'Do_pH_Filtarte_2hr_lag',
                'TRP_2_Viscosity_2hr_lag',
                'PO2_Press_Pulp_Consistency_2hr_lag',
                'Do_Tower_Inlet_Temperature_2hr_lag',
                'PO_2_Press_Pulp_Flow_2hr_lag',
                'd0_outlet_brightness',
                'trp2_outlet_brightness',
                'D0_pulp_pH',
                'ClO2_concentration',
                'recommended_dosage'
            )

            for dosage in dosage_fields:
                writer.writerow(dosage)
                # print(input_date)

        for i in range(days):
            current_date = initial_date
            foo(current_date)
            initial_date = initial_date + timedelta(days=1)
        return response

class BrightnessAuto(generics.ListAPIView):
    """
    API for fatch data form pi connector and predict 
    data from model and return recommended dosags
    """
    @transaction.atomic()
    def list(self, request, *args, **kwargs):
        user = self.request.user
        newUser = NewUser.objects.filter(pk=user.pk)
        req_user = None
        if newUser.exists():
            req_user = newUser.first()            
        pi_data = get_data_from_pi()
        if pi_data['D0_H2SO4_flow_2hr_lag'] < 0:
            pi_data['D0_H2SO4_flow_2hr_lag'] = 0

        pi_data['d0_outlet_brightness'] = SaveDefaultValue.objects.last().d0_outlet_brightness

        pi_data_copy = copy.deepcopy(pi_data)
        recomondation_clo2_flow = predictions(pi_data)
        updated_at = datetime.now().strftime("%Y-%d-%m, %I:%M:%S %p")
        pi_data_copy.update({
            "recommended_dosage": recomondation_clo2_flow
        })
        save_data_into_db(pi_data_copy, req_user)
        pi_data_copy['updated_at'] = updated_at
        pi_data_copy['error sensors'] = []
        return Response(pi_data_copy)


class SaveDefaultValueView(generics.CreateAPIView):
    def create(self, request, *args, **kwargs):
        data = request.data
        d0_outlet_brightness = data['d0_outlet_brightness']

        SaveDefaultValue.objects.create(
            d0_outlet_brightness=d0_outlet_brightness
        )
        return Response({"sucess: true"})


class ChartDataListAPI(generics.ListAPIView):

    def get_queryset(self):
        start_time = self.request.query_params.get('start_time')
        end_time = self.request.query_params.get('end_time')

        start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S') if start_time else None
        end_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S') if end_time else None

        queryset = Dosage.objects.all()
        if start_time is not None and end_time is not None:
            queryset = Dosage.objects.filter(
                date__gte=start_time.date(), 
                # time__gte=start_time.time(),
                date__lte=end_time.date(),
                # time__lte=end_time.time()
                )
        else:
            queryset = []

        return queryset

    def list(self, request, *args, **kwargs):
        data = self.get_queryset()
        response = {
            "timestamps": [],
            "orig_clo2": [],
            "recc_clo2": [],
            "orig_d0_brig": [],
            "recc_d0_brig": [],
            "orig_pulp_brig": [],
            "recc_pulp_brig": []
        }

        for d in data:
            time_stamp = datetime.combine(d.date, d.time).strftime("%d/%m/%Y %H:%M:%S")
            response['timestamps'].append(time_stamp)
            response['orig_clo2'].append(d.D0_Cl2_flow)
            response['recc_clo2'].append(round(d.recommended_dosage, 2))
            response['orig_d0_brig'].append(d.D0_Brightness_SAP)
            response['recc_d0_brig'].append(d.d0_outlet_brightness)
            response['orig_pulp_brig'].append(d.Loose_Pulp_brightness)
            response['recc_pulp_brig'].append(d.trp2_outlet_brightness)

        return Response(response)